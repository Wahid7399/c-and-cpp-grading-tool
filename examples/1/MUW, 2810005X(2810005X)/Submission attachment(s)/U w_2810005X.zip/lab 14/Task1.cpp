#include <iostream>
#include<iomanip>
using namespace std;

int main(){
    int num;
    int n;
    int m;
    cout<<"enter size of array A" << endl;
    cin>> m;

    //initialize arrayA
    int *arrA = new int[m];
    cout << "enter elements of first array" <<endl;
    for(int i =0; i<m ; i++){
        cin >> num;
        arrA[i] = num;
    }

    cout<<"enter size of array B" << endl;
    cin>> n;

    //initialize arrayB
    int *arrB = new int[n];
    cout << "enter elements of second array" <<endl;
    for(int i =0; i<n ; i++){

        cin >>num;
        arrA[i] = num;
    }
    //arrayC
    int Totalsize = m+n;
    int *arrC = new int[Totalsize];
    for(int i = 0 ; i < m ; i++){
        arrC[i] = arrA[i];
    }
    for(int i = 0; i < n ; i++){
        arrC[i+ m] = arrB[i];
    }
    //bubblesort
    for(int i = 0; i < Totalsize -1 ; i++){
        for(int j = 0; j < Totalsize -1 - i; j++){
            if (arrC[j] > arrC[j +1]){
                int temp = arrC[j];
                arrC[j] = arrC[j+1];
                arrC[j+1] = temp;
            
            }
        }
    }

    int *result = new int[Totalsize];
    int resultsize = 0;
    for (int i = 0; i < Totalsize; i++){
        if (i == 0 || arrC[i] != arrC[i-1]){
            result[resultsize++] = arrC[i];

        }
    }
    cout<< "sorted merged array"<<endl;
    for(int i = 0 ; i < resultsize; i++){
        cout << result[i] <<" ";
    }
    cout <<endl;


    delete[] arrA;
    delete[] arrB;
    delete[] arrC;
    delete[] result;

    return 0;


}