//Note: My computer did not have the required extension to show the errors hance i wasnt bale to debig the code. sir knows this and has allowed me t submit like this, hoping the TA could add the cde to chatgpt to debug

#include <iostream>
#include<iomanip>
using namespace std;



 string* songname = nullptr;
    int* songlength = nullptr;
    int capacity = 2;
    int size = 0;


void resizearray(){
        capacity = capacity*2;
        string* newsongname = new string[capacity];
        int* newsonglength = new int[capacity];

        for(int i = 0; i< size; i++){
            newsongname[i] = songname[i];
            newsonglength[i] = songlength[i];
        }
    delete[] songname;
    delete[] songlength;
    songname = newsongname;
    songlength = newsonglength;

}

void addsong(){
    string name;
    int length;

    cout<<"enter song name: "<<endl;
    cin.ignore();
    getline(cin, name);

    cout <<"enter song length in seconds: "<<endl;
    cin << length;

    if(length < 0){
        cout << "invalid song length, please enter a positive value"<<endl;
        return;
    }
    if(size == capacity){
        resizearray();
    }
    songname[size] = name;
    songlength[size] = length;
    size++;

    cout<<"song added successfully"<<endl;
}

void deletesong(){
    string name;
    cout<<"enter the name of the song to be deleted"<<endl;
    cin.ignore();
    getline(cin, name);

    int index = -1;
    for(int i =0; i< size; i++){
        if(songname[i] == name){
            index = i;
            break;
        }
    }
    if(index == -1){
        cout <<"Song is not found in he playlist"<<endl;
        return;
    }
    for(int i = index; i < size -1 ; i++){
        songname[i] = songname[i +1];
        songlength[i] = songlength [i+1];
    }
    size--;
    cout< "song has been deleted successfully"<<endl;
}

void displayplaylist(){
    if(size ==0){
        cout<<"the playlist is empty"<<endl;
        return;
    }
    cout<<"Playlist"<<endl;
    for(int i = 0; i < size; i++){
        int minutes = songlength[i]/60;
        int seconds = songlength [i]%60;
        cout << i+1 << ". "<<songname<< "  (" << minutes <<"m " << seconds <<"s)"<<endl;
    }
}
void calculatetotalduration(){
    if (size == 0){
        cout << "playlist is empty"<<endl;
    }   

    int totalseconds = 0;
    for(int i = 0; i<size; i++){
        totalseconds = songlength[i];
    }
    int hours = totalseconds/3600;
    int minutes = totalseconds%3600;
    int seconds = totalseconds %60;
    cout<<" total duration"<< hours << "h " << minutes <<"m "<<seconds <<"s "<< endl;
}
void exitprogram(){
    delete[] songname;
    delete[] songlength;
}

int main(){
 
    songname = new string[capacity];
    songlength = new int[capacity];
    int choice;

    do{
        cout << "\nDynamic playlist manager"<<endl;
        cout<<"1.addsong"<<endl;
        cout<<"2.delete song"<<endl;
        cout<<"3.display playlist"<<endl;
        cout<<"4. calculate totla duration"<<endl;
        cout << "5. exit program"<<endl;




        cin>>choice;

        switch(choice){
            case 1:
                addsong();
                break;
            case 2:
                deletesong();
                break;
            case 3:
                displaylist();
                break;
            case 4:
                calculatetotalduration();
                break;
            case5:
                exitprogram();
                break;
            default:
                cout<<"invalid choice";
        }
    
        
    }while(choice != 5);
    return 0;
    
   
}