#include<iostream>
#include<string>
using namespace std;

void resize(char **&names, int *&lengths, int &capacity) 
{
    capacity *= 2;
    
    char **newNames=new char*[capacity];
    int *newLengths=new int[capacity];
    
    for (int i=0;i<capacity;i++) 
    {
        newNames[i]=names[i];
        newLengths[i]=lengths[i];
    }
    
    delete[] names;
    delete[] lengths;
    
    names=newNames;
    lengths=newLengths;
}

void addSong(char **&names, int *&lengths, int &size, int &capacity) 
{
    if (size==capacity) 
    {
        resize(names, lengths, capacity);
    }
    
    char songName[100];
    int length;
    
    cout<<"Enter song name: ";
    getline(cin, songName);
    
    cout<<"Enter song length (in seconds): ";
    while(true) 
    {
        cin>>length;
        if(length>0) 
            break;
        else 
        {
            cout<<"Invalid length. Please enter a valid song length in seconds: ";
        }
    }
}

void deleteSong(char **&names, int *&lengths, int &size) 
{
    char songToDelete[100];
    
    cout<<"Enter the name of the song to delete: ";
    getline(cin, songToDelete);
    
    int index = -1;
    for (int i=0;i<size;i++) 
    {
        bool match=true;
        int j=0;
        while(names[i][j]!='\0' && songToDelete[j]!='\0') 
        {
            if(names[i][j]!=songToDelete[j]) 
            {
                match=false;
                break;
            }
            j++;
        }
        
        if(match && names[i][j]=='\0' && songToDelete[j]=='\0') 
        {
            index=i;
            break;
        }
    }
    
    if(index==-1) 
    {
        cout<<"Song not found"<<endl;
        return;
    }
    
   
    delete[] names[index]; 
    for(int i=index;i<size-1;i++) 
    {
        names[i]=names[i + 1];
        lengths[i]=lengths[i + 1];
    }
    
    size--;
    cout<<"Song deleted successfully!"<<endl;
}


void display(char **names, int *lengths, int size) 
{
    if (size==0) 
    {
        cout<<"Playlist is empty"<<endl;
        return;
    }
    
    cout<<"Playlist"<<endl;
    for (int i=0;i<size;i++) 
    {
        int minutes = lengths[i] / 60;
        int seconds = lengths[i] % 60;
        cout<<names[i]<<" - "<<minutes<<"m "<<seconds<<"s"<<endl;
    }
}



void total(int *lengths, int size) 
{
    int totalSeconds=0;
    for (int i=0;i<size;i++) 
    {
        totalSeconds += lengths[i];
    }
    
    int hours=totalSeconds/3600;
    totalSeconds %= 3600;
    int minutes=totalSeconds/60;
    totalSeconds %= 60;
    
    cout<<"Total duration: "<<hours<<"h "<<minutes<< "m "<<totalSeconds<<"s"<<endl;
}





int main() {
    int capacity = 2;    
    int size = 0;       
    
    
    char **names = new char*[capacity];
    int *lengths = new int[capacity];
    
   
    int choice;

    cout<<"Music Playlist Menu: "<<endl;
    cout<<"1. Add a Song"<<endl;
    cout<<"2. Delete a Song"<<endl;
    cout<<"3. Display a playlist"<<endl;
    cout<<"4. Calculate Total duration"<<endl;
    cout<<"5. Exit."<<endl;

    cout<<"Enter a choice: ";
    cin>>choice;

    if(choice==1)
        addSong(&names, &lengths, &size, &capacity);
    
    if(choice==2)
        deleteSong(&names, &lengths, &size);

    if(choice==3)
        display(names, lengths, size);

    if(choice==4)
        total(lengths, size);

    if(choice==5)
        cout<<"exitting. . ."<<endl;

    if(choice!=1 || choice!=2 || choice!=3 || choice!=4 || choice!=5)
        cout<<"enter valid number"<<endl;
    
    
    
}
