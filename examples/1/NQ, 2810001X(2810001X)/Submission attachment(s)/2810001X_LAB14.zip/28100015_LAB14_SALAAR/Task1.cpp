#include<iostream>
using namespace std;

int main()
{
    int m,n;
    cout<<"enter the size of the first array: ";
    cin>>m;

    int *A = new int[m];

    for(int i=0;i<m;i++)
    {
        cout<<"enter elements of first array: ";
        cin>>*(A+i);
    }

    cout<<"enter the size of the second array: ";
    cin>>n;

    int *B = new int[n];

    for(int i=0;i<n;i++)
    {
        cout<<"enter elements of second array: ";
        cin>>*(B+i);
    }

    int *C= new int[m+n];

    for(int i=0;i<m;i++)
    {
        *(C+i)=*(A+i);
    }

    for(int i=0;i<n;i++)
    {
        *(C+i+m)=*(B+i);
    }

    int temp;
    for(int i=0;i<m+n-1;i++)
    {
        for(int j=0;j<m+n-1-i;j++)
        {
            if(*(C+j)>*(C+j+1))
            {
                temp=*(C+j);
                *(C+j)=*(C+j+1);
                *(C+j+1)=temp;
            }
            
           
        }
    }

    int* uniqueArray=new int[m+n];
    int uniqueCount=0;

    for(int* ptr=C;ptr<C+m+n;ptr++) 
    {
       
        if(ptr==C || *ptr!=*(ptr - 1)) 
        {
            *(uniqueArray+uniqueCount++)=*ptr;
        }
    }


    cout<<"Sorted merged array: ";
    for (int* ptr=uniqueArray;ptr<uniqueArray+uniqueCount;ptr++) 
    {
        cout<<*ptr<<" ";
    }
    cout<<endl;
    
    delete[] A;
    delete[] B;
    delete[] C;
    delete[] uniqueArray;

}