#include<iostream>
#include<iomanip>
using namespace std;

void inputArray(int *array,int size)
{
    for(int i=0;i<size;i++)
    {
        cin>>array[i];
    }
}

void printArray(int *array,int size)
{
    for(int i=0;i<size;i++)
    {
        cout<<array[i]<<" ";
    }
}

void sortArray(int *array,int size,int max)
{
    // printArray(array,size);
    cout<<endl;
    for(int i=0;i<size;i++)    
    {
        for(int j=i;j<size;j++)    
        {
            if(array[i]>array[j])
            {
                int temp=array[j];
                // max=array[j+1];
                array[j]=array[i];
                array[i]=temp;
            }
        }
    }
    cout<<"This is the sorted array : "<<endl;
    printArray(array,size);
}



int main()
{
    int m=0;
    int n=0;
    cout<<"Enter size of first array : "<<endl;
    cin>>m;
    cout<<"Enter size of second array : "<<endl;
    cin>>n;
    int *A =new int[m];
    int *B =new int[n];
    inputArray(A,m);
    inputArray(B,n);
    cout<<"This is array A : "<<endl;
    printArray(A,m);
    cout<<"This is array B : "<<endl;
    printArray(B,n);
    int size=n+m;
    int *C =new int[m+n];
    for(int i=0;i<m;i++)
    {
        C[i]=A[i];
    }
    for(int i=m;i<size;i++)
    {
        C[i]=B[i-m];
    }
    cout<<"This is array C : "<<endl;

    for(int i=0;i<size;i++)
    {
        cout<<C[i]<<" ";
    }
    int max=C[size];

    sortArray(C,size,max);

 }