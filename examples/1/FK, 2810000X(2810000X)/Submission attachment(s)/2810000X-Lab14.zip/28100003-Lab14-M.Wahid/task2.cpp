#include<iostream>
#include<iomanip>
using namespace std;

void inputArray(int *array,int size)     //please check individual functions program is not running in main function 
                                         //Thank you so much!
{
    for(int i=0;i<size;i++)
    {
        cin>>array[count];
        count++;
    }
}
void exit(int *array)
{
    delete[] array[];
}

void printArray(int *array,int size)
{
    for(int i=0;i<size;i++)
    {
        cout<<array[i]<<" ";
    }
}
void printArray(char *array,int size)
{
    for(int i=0;i<size;i++)
    {
        cout<<array[i]<<" ";
    }
}

void resizeFunction(char *array)
{
    if(count==size-1)
    {
        int size_new =size*2;
    }
    int *temp= new string [size];
    for(i=0;i<new_size;i++)
    {
        temp[i]=array[i];
    }
    delete[] array[];
    array=temp;
    delete[] temp;
}
void resizeFunction(int *array)
{
    if(count==size-1)
    {
        int size =size*2;
    }
    int *temp= new string [size];
    for(i=0;i<size/2;i++)
    {
        temp[i]=array[i];
    }
    delete[] array[];
    array=temp;
    delete[] temp;
}
void addSongLength(int *array)
{
    for(int i=size;i<new_size;i++)
    {
        cin>>array[i];
    }
}
void addSong(char *array)
{
    inputArray(array,size);
    if(count>=size)
    {
        resizeFunction(array);
    }

    for(int i=size;i<size/2;i++)
    {
        cin>>array[i];
    }
    addSongLength(array);
}

void deleteSongLength(int *array,int index)
{
    int temp=0;
    for(int i=0;i<size;i++) 
    {
        if(i==index||i>index)
        {
            temp[index]=array[i+1];
        }
        else
        {
            temp[index]=array[i];
        }
    }
    delete[] array[];
    array=temp;
    delete[] temp[];
}
void deleteSong(char *array,int index)
{
    int temp=0;
    for(int i=0;i<size;i++) 
    {
        if(i==index||i>index)
        {
            temp[index]=array[i+1];
        }
        else
        {
            temp[index]=array[i];
        }
    }
    delete[] array[];
    array=temp;
    delete[] temp[];
}

int duration(int *array)
{
    int sum=0;
    for(int i=0;i<size;i++)
    {
        sum+=array[i];
    }
}




int main()
{
    int size=2;
    int choice=0;
    string *song_name= new string[size];
    int *song_length= new int[size];
    do
    {
        cout<<"enter your choice : "<<endl;
        cout<<"1. Add songs : "<<endl;
        cout<<"2. Delete songs : "<<endl;
        cout<<"3. Display songs : "<<endl;
        cout<<"4. Calculate sum : "<<endl;
        cout<<"5. Exit : "<<endl;

        cin>>choice;
        switch(choice)
        case 1:
        {
            addSong(song_name);
            addSongLength(song_length);
        }
        case 2:
        {
            deleteSong(song_name,index);
            deleteSong(song_length,index);
        }
        case 3:
        {
            printArray(song_name,size);
            printArray(song_length,size);
        }
        case 4:
        {
            duration(song_name);
            duration(song_length);
        }
        case 5:
        {
            exit(song_name);
            exit(song_length);
            break;
        }while(choice!=5);
    }
}